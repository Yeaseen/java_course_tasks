/**
 * 
 */
/**
 * @author yeaseenarafat
 *
 */
module Project2 {
	requires java.desktop;
}