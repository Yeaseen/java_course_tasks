package project2;

public class WordNode {
	
	public String data; 
	
	public WordNode next;
	
	
	public WordNode(String word) {
		data = word;
		next = null;
	}

}
